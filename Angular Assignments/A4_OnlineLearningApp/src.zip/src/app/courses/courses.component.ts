// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-courses',
//   standalone: false,
  
//   templateUrl: './courses.component.html',
//   styleUrl: './courses.component.css'
// })
// export class CoursesComponent {

// }
import { Component } from '@angular/core';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  standalone:false
})
export class CoursesComponent {
  courses = [
    { id: 1, name: 'Angular Basics' },
    { id: 2, name: 'Advanced Angular' }
  ];
}